

// Import Bootstrap JS
import * as bootstrap from 'bootstrap';
import './custom.js';


// Import SCSS
import '../scss/style.scss';